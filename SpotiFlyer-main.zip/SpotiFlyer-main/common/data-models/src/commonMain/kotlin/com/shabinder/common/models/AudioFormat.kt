package com.shabinder.common.models

enum class AudioFormat {
    MP3, MP4, FLAC, UNKNOWN
}