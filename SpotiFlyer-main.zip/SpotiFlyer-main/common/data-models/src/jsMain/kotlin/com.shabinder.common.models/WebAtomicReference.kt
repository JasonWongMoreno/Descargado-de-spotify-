package com.shabinder.common.models

actual class NativeAtomicReference<T> actual constructor(actual var value: T)