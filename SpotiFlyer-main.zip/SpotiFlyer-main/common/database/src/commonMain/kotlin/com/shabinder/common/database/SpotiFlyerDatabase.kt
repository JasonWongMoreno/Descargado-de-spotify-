package com.shabinder.common.database

import com.shabinder.database.Database

/* Database Wrapper */
class SpotiFlyerDatabase(val instance: Database?)
