package com.shabinder.common.core_components.picture

expect class Picture