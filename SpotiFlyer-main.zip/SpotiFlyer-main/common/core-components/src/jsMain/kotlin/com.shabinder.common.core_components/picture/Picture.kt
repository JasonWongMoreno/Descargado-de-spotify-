package com.shabinder.common.core_components.picture

actual data class Picture(
    var imageUrl: String
)