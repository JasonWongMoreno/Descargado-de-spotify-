package com.shabinder.common.di

import platform.UIKit.UIImage

actual data class Picture(
    val image: UIImage?
)
