package com.shabinder.common.core_components.picture

import androidx.compose.ui.graphics.ImageBitmap

actual data class Picture(
    var image: ImageBitmap?
)