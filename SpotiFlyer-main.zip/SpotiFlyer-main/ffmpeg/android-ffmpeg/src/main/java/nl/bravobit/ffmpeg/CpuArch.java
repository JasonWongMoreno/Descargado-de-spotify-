package nl.bravobit.ffmpeg;

public enum CpuArch {
    ARMv7, x86, x86_64, ARM_64, NONE
}
