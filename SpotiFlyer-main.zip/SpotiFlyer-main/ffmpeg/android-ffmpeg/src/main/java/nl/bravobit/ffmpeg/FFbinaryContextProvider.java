package nl.bravobit.ffmpeg;

import android.content.Context;

public interface FFbinaryContextProvider {

    Context provide();
}
