package nl.bravobit.ffmpeg;

public interface FFbinaryObserver extends Runnable {

    void cancel();
}
