package nl.bravobit.ffmpeg;

public class ExecuteBinaryResponseHandler implements FFcommandExecuteResponseHandler {

    @Override
    public void onSuccess(String message) {

    }

    @Override
    public void onProgress(String message) {

    }

    @Override
    public void onFailure(String message) {

    }

    @Override
    public void onStart() {

    }

    @Override
    public void onFinish() {

    }
}
