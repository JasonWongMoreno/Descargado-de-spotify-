package models.matomo

typealias MatomoDownloads = ArrayList<MatomoDownloadsItem>
