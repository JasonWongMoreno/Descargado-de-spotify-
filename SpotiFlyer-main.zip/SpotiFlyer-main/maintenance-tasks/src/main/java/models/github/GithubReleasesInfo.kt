package models.github

typealias GithubReleasesInfo = ArrayList<GithubReleaseInfoItem>
