### Contibuting Translations:

 - **Fork** this repo (Button at top Right Corner)
 
 - Create **Strings_{language-code}.properties.xml**  in  **/translations/**
   
   - Refer **Default File** with English **(en)** = [Strings_en.properties](https://github.com/Shabinder/SpotiFlyer/blob/main/translations/Strings_en.properties)
   
   - Like if you want to translate app to **French** , create **Strings_fr.properties**
   
   - **Copy** all Key-Value pairs from **Strings_en.properties -> Strings_fr.properties and Translate all Values.**
 
 - **Commit** your Changes to your Fork and then **Create a Pull Request** to this Repo.
 
 - **Sit Back and Relax** and **kudos** for your contibution 👍 , many people will appreciate your effort. 😄

If Need any Help with Anything create an issue asking about for same.
